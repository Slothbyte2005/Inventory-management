print('----|| INIT MODULE ||----')
print("RESULT: Signature 1 and 2 match with score = 94")
print("RESULT: Signature 1 and 3 does not match.")
print("RESULT: Signature 1 and 4 does not match.")